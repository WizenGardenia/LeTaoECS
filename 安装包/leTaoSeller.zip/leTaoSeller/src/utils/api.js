module.exports = {
    // 开发环境
    path:"http://localhost:8000",
    // 生产环境
    // path:"http://www.ccqu.com",
}