package cn.edu.cqu.letao.mapper;

import cn.edu.cqu.letao.entity.Shop;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * SHOP Mapper 接口
 * </p>
 *
 * @author just
 * @since 2021-07-20
 */
public interface ShopMapper extends BaseMapper<Shop> {

}
