<!--
 * @Description: 
 * @Author: hai-27
 * @Date: 2020-02-27 13:57:14
 * @LastEditors: hai-27
 * @LastEditTime: 2020-02-27 14:11:31
 -->
<template>
  <div class="error">
    <div class="main"></div>
  </div>
</template>
<style>
.error {
  height: 500px;
  width: 1225px;
  margin: 0 auto;
}
.error .main {
  margin: 0 362.5px;
  height: 500px;
  background: url(../assets/imgs/error.png) no-repeat;
}
</style>